
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
	
    public MyServlet() {
        // TODO Auto-generated constructor stub
    	
    		
    }
    public void connessione() throws SQLException
    {
    	Connection con=null;
    	ResultSet result;
    	 Statement stat = con.createStatement();
    	 String sql;
		
		String url = "jdbc:mysql://localhost:3306/noleggio?user=root&password=";
		String database = "noleggio";
		String user = "root";
		String password = "";
		
		try {
			con = DriverManager.getConnection(url+database, user, password);
			System.out.println("Connessione al server DBMS effettuata.");
			con.close();
		}
		catch(SQLException exception) {
			System.err.println("Errore di connessione al server DBMS.");
		}
	
	 result = stat.executeQuery("SELECT nome,cognome FROM clienti;");
	 while (result.next()) {
		 String name = result.getString("Nome");
		 String cognome = result.getString("congome");
		 System.out.println(name+""+ cognome);
	 }
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
