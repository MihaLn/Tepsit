import java.util.Scanner;

public class TestEs2 {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Jparser j;
		
		System.out.println("Inserire il percorso del file xml:");
		j= new Jparser(sc.nextLine());//C:\Users\Utente\Desktop\tepsit04022020Eteri\verifica_tepsit\src\Monumenti.xml
		j.addItem("Museo Guatelli", "Ricc�", "Storia", "4");
		j.docReader();
		
		sc.close();

	}

}
