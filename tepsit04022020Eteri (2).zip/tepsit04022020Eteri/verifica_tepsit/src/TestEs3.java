import java.util.Scanner;

import javax.lang.model.element.Element;
import javax.xml.parsers.ParserConfigurationException;

public class TestEs3 {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Jparser j,jj;
		
		System.out.println("Inserire il percorso del file xml:");
		j= new Jparser(sc.nextLine());//C:\Users\Utente\Desktop\tepsit04022020Eteri\verifica_tepsit\src\Monumenti.xml
		j.addItem("Museo Guatelli", "Ricc�", "Storia", "4");
		
		jj = new Jparser(j.getRoot());
		
		jj.docReader();
		
		j.docReader();
		
		sc.close();

	}

}
