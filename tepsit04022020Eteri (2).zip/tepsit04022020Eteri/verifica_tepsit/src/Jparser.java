import java.io.*;

import javax.xml.parsers.*;

import org.w3c.dom.*;
import org.xml.sax.SAXException;

public class Jparser 
{
	Document doc;
	Element root;
	
	public Jparser(String filename)//costruttore a cui viene passato il nome di un file e genera l'albero
	{
		try {
			this.doc = this.parseFile(filename);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		this.root = doc.getDocumentElement();//ottiene l'elemento radice dell' albero
	}
	
	public Element getRoot()
	{
		return root;
	}
	
	public Jparser(Element root)
	{
		try {
			this.doc = this.parseFile(null);
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// conterr� la struttura ad albero generata dal parsing
		catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		this.doc.appendChild(this.doc.createElement("Monumenti"));
		
		this.root=this.doc.getDocumentElement();
		
		NodeList monumenti = this.root.getElementsByTagName("Monumento");
		
		if(monumenti != null && monumenti.getLength()>0)//controlla che la collection non sia cuota
		{
			for(int i=0; i<monumenti.getLength();i++)//scorre la collection
			{
				Element monumento = (Element) monumenti.item(i);
				Element nome = (Element) monumento.getElementsByTagName("Nome").item(0);//prendo gli elementi dispari perch� contengono il valore (visto col debugger)
				Element luogo = (Element) monumento.getElementsByTagName("Luogo").item(0);//e li metto in variabili di tipo Element perch� detta un po' male: i loro figli non hanno figli
				Element categoria = (Element) monumento.getElementsByTagName("Categoria").item(0);
				Element costo = (Element) monumento.getElementsByTagName("Prezzo").item(0);
				addItem(nome.getFirstChild().getNodeValue(),luogo.getFirstChild().getNodeValue(),categoria.getFirstChild().getNodeValue(),
						costo.getFirstChild().getNodeValue());
	
			}
		}
		
		docReader();
		

	}
	
	public void docReader()
	{		
		NodeList monumenti = this.root.getElementsByTagName("Monumento");//collection di nodi che contiene tutti gli elementi con tag Monumento e anche i tag figli ecc..
		
		if(monumenti != null && monumenti.getLength()>0)//controlla che la collection non sia vuota
		{
			for(int i=0; i<monumenti.getLength();i++)//scorre la collection
			{
				Element monumento = (Element) monumenti.item(i);//siccome anche film contiene dei tag figli lo metto in una nedelist
				//prendo ogni singolo figlio a partire dal tag (item 0 perch� esiste un solo figlio con quel tag)
				Element nome = (Element) monumento.getElementsByTagName("Nome").item(0);
				Element luogo = (Element) monumento.getElementsByTagName("Luogo").item(0);
				Element categoria = (Element) monumento.getElementsByTagName("Categoria").item(0);
				Element costo = (Element) monumento.getElementsByTagName("Prezzo").item(0);
				
				//stampo prendento il primo figlio che equivale al valore testuale e poi lo trasformo in stringa con .getNodeValue
				System.out.println(nome.getFirstChild().getNodeValue()+"\n"+luogo.getFirstChild().getNodeValue()+"\n"+
								   categoria.getFirstChild().getNodeValue()+"\n"+costo.getFirstChild().getNodeValue()+"\n");
			}
		}
	}
	
	public void addItem(String nome, String luogo, String categoria, String costo)
	{
		
		Element monument = doc.createElement("Monumento");//creo un elemento con tag Monumento
		Element name = doc.createElement("Nome");//creo un elemento con tag Nome
		Element place = doc.createElement("Luogo");//creo un elemento con tag Luogo
		Element cat = doc.createElement("Categoria");//creo un elemento con tag Categoria
		Element price = doc.createElement("Prezzo");//creo un elemento con tag Prezzo
		
		Text textName = doc.createTextNode(nome);//Creo un nodo testuale che avr� valore la variabile nome passata come parametro
		Text textPlace = doc.createTextNode(luogo);//Creo un nodo testuale che avr� valore la variabile luogo passata come parametro
		Text textCat = doc.createTextNode(categoria);//Creo un nodo testuale che avr� valore la variabile categoria passata come parametro
		Text textPrice = doc.createTextNode(costo);//Creo un nodo testuale che avr� valore la variabile ora costo come parametro
		
		//aggiungo agli elementi appena creati dei figli con valore testuale
		name.appendChild(textName);
		place.appendChild(textPlace);
		cat.appendChild(textCat);
		price.appendChild(textPrice);
		
		//aggiungo gli elementi creati prima all'elemento con tag Monumento mettendo
		monument.appendChild(name);
		monument.appendChild(place);
		monument.appendChild(cat);
		monument.appendChild(price);
		
		root.appendChild(monument);// aggiungo il nuovo elemento Monumento nell'ultima posizione della radice
	}
	
	private Document parseFile(String filename) throws ParserConfigurationException, SAXException, IOException // metodo per il parsing del documento
	{
		DocumentBuilderFactory factory;// per il parsing
		DocumentBuilder builder; //per il parsing
		Document doc;// conterr� la struttura ad albero generata dal parsing
		
		factory = DocumentBuilderFactory.newInstance();// parsing
		builder = factory.newDocumentBuilder();// parsing
		
		if(filename != null)
		{
			doc = builder.parse(filename);// genera una struttura ad albero e la mette nella variabile doc
		}
		
		doc = builder.newDocument();
		
		return doc;//ritorna la struttura ad albero
	}

}